/*
 * Export addCucumberContext function
 *
 */

module.exports = require('./lib/addCucumberContext')
